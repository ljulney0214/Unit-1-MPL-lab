/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package unit3ampllab;

//Write a program that prompts a user for the number of eggs in the order
//and then display the amount owed with a full explanation. For example, 
//typical output might be You ordered 27 eggs. 


import java.util.Scanner;  // Import the Scanner class for user input

public class Eggs {
    public static void main(String[] args) {
        // Create a Scanner object to read from the console
        Scanner scan;
        scan = new Scanner(System.in);
        
        // Prompt the user for the number of eggs ordered
        System.out.print("Enter the number of eggs: ");
        int eggs = scan.nextInt();
        
        // Calculate the number of dozens and the remaining loose eggs
        int dozens = eggs / 12;      // Full dozens
        int looseEggs = eggs % 12;     // Eggs that are not part of a dozen
        
        // Define the prices
        double pricePerDozen = 3.25;
        double pricePerLooseEgg = 0.45;
        
        // Calculate the total cost
        double totalCost = dozens * pricePerDozen + looseEggs * pricePerLooseEgg;
        
        // Display the order summary and total cost using string concatenation
        System.out.println("You ordered " + eggs + " eggs. That's " + dozens +
        " dozen at $" + pricePerDozen + " per dozen and " +
           looseEggs + " loose eggs at 45 cents each for a total of $" 
                + totalCost + ".");
    }
}
