/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */


//Create an application named Percentages whose main() method holds two 
//double variables, and prompt the user for values. Pass both variables to a 
//method named computePercent() that displays the two values and the value of 
//the first number as a percentage of the second one. For example, if the 
//numbers are 2.0 and 5.0, the method should display a statement similar to 2.0
//is 40 percent of 5.0. Then call the method a second time, passing the values 
//in reverse order.

import java.util.Scanner;

public class Percentages {
    public static void main(String[] args) {
        // Create a Scanner object called scan to read user input.
        Scanner scan;
        scan = new Scanner(System.in);
        
        // Prompt the user for the first double value.
        System.out.print("Enter the first number: ");
        double num1 = scan.nextDouble();
        
        // Prompt the user for the second double value.
        System.out.print("Enter the second number: ");
        double num2 = scan.nextDouble();
        
        // Call computePercent() with the numbers as entered.
        computePercent(num1, num2);
        
        // Call computePercent() with the numbers in reverse order.
        computePercent(num2, num1);
    }
    
    //Computes the percentage of the first value relative to the second value
    //and displays the result.
    //a the value to be expressed as a percentage
    //the value that represents 100
    
    public static void computePercent(double first, double second) {
        double percentage = (first / second) * 100;
        System.out.println(first + " is " + percentage + " percent of " + second);
    }
}
