/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab5mpl;

import java.util.Scanner;

public class CarCareChoice {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Available services and their prices
        String[] services = {"oil change", "tire rotation", "battery check", "brake inspection"};
        double[] prices = {25.00, 22.00, 15.00, 5.00};

        // Prompt user for a service choice
        System.out.println("Welcome to Chapa's Car Care Shop!");
        System.out.println("Available services: ");
        for (String service : services) {
            System.out.println(service);
        }

        System.out.print("Enter the service you want: ");
        String choice = scanner.nextLine().toLowerCase();

        // Check if the service entered is valid
        boolean validChoice = false;
        for (int i = 0; i < services.length; i++) {
            if (choice.equals(services[i])) {
                System.out.println("You selected " + services[i] + " for $" + prices[i]);
                validChoice = true;
                break;
            }
        }

        // If invalid choice
        if (!validChoice) {
            System.out.println("Invalid service. Please choose a valid option.");
        }

    }
}
