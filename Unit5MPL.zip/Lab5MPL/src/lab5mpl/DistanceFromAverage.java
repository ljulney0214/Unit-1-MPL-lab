/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab5mpl;

import java.util.Scanner;

public class DistanceFromAverage {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double[] numbers = new double[15];
        int count = 0;
        double sum = 0;

        // Prompt the user to enter numbers
        System.out.println("Enter up to 15 numbers (enter 99999 to quit):");
        
        while (count < 15) {
            double num = scanner.nextDouble();
            
            if (num == 99999) {
                break;
            }
            
            numbers[count] = num;
            sum += num;
            count++;
        }

        // If no numbers were entered
        if (count == 0) {
            System.out.println("Error: No numbers entered.");
        } else {
            // Calculate the average
            double average = sum / count;

            // Display the results
            System.out.println("You entered " + count + " numbers.");
            System.out.println("The arithmetic average is: " + average);

            // Display each number and its distance from the average
            for (int i = 0; i < count; i++) {
                double distance = Math.abs(numbers[i] - average);
                System.out.println("Number: " + numbers[i] + ", Distance from average: " + distance);
            }
        }

    }
}
